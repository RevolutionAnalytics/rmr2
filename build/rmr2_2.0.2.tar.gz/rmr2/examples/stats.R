rmr.sample = function(input, output, rate, rate = NULL, size = NULL, input.size = NULL)
  if()